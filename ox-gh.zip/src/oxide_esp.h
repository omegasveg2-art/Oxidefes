// oxide_esp.h — ESP for "Oxide" (Android, il2cpp, arm64, Mirror). Header-only, needs imgui.h.
// Nothing is hardcoded: classes/fields/methods are resolved by NAME via il2cpp exports, offsets come from the runtime.
// dump.cs: [FieldOffset]/[Address] attributes are bogus; only the trailing "// 0x" comments match script.json. Not used here.
// Obfuscated names (vd, XE, XU, Xq, cJQ...) change per build -> only readable names are used:
//   Oxide.PlayerManager{EnabledInstances, vitals, get_teamName}, vitals->..->XU.Entity -> XE{Health, DisplayName}, GenericVitals.m_MaxHealth
// Call ox::Init() once after libil2cpp.so is loaded, ox::Esp() every frame from your render hook, ox::Menu() inside your ESP tab.
// Play Integrity SDK is in the build, treat the account as burnable. Managed calls run on the GL thread — if it crashes, move ox::Snapshot() into a main-thread hook.
#pragma once
#include <dlfcn.h>
#include <cstdint>
#include <cstring>
#include <cmath>
#include <cstdio>
#include <vector>
#include <string>
#include "imgui.h"

namespace ox {

struct V3 { float x, y, z; };

struct Cfg {
    bool esp = false, box = true, health = true, name = true, dist = true, line = false, team = false;
    float maxDist = 400.f;
    ImVec4 colEnemy{1.f, 0.25f, 0.25f, 1.f}, colTeam{0.25f, 0.9f, 0.4f, 1.f};
} cfg;

// ---- il2cpp api ----
static void* (*domain_get)();
static void* (*thread_attach)(void*);
static void** (*domain_get_assemblies)(void*, size_t*);
static void* (*assembly_get_image)(void*);
static void* (*class_from_name)(void*, const char*, const char*);
static void* (*class_get_parent)(void*);
static void* (*class_get_field)(void*, const char*);
static void* (*class_get_method)(void*, const char*, int);
static void* (*class_get_methods)(void*, void**);
static void* (*class_from_type)(void*);
static void* (*class_elem)(void*);
static int (*class_array_elem_size)(void*);
static int (*class_inst_size)(void*);
static void* (*obj_get_class)(void*);
static size_t (*field_offset)(void*);
static void* (*field_type)(void*);
static void (*field_static_get)(void*, void*);
static int (*method_param_count)(void*);
static void* (*method_ret_type)(void*);
static const char* (*type_name)(void*);
static const uint16_t* (*string_chars)(void*);
static int (*string_len)(void*);

static bool g_ok = false;
static size_t oVitals, oSlots, oLast, oSlotVal, szSlot;
static size_t oEntity, oHealth, oName;
static void *fEnabled, *mTransform, *mPosition, *mMain, *mW2S, *mScrW, *mScrH, *mTeam, *mHpGet;
static void* kHpClass;

template <class T> static void ld(T& f, void* h, const char* n) { f = (T)dlsym(h, n); }

static void* FindClass(const char* ns, const char* name) {
    size_t n = 0; void** as = domain_get_assemblies(domain_get(), &n);
    for (size_t i = 0; i < n; i++) {
        void* img = assembly_get_image(as[i]);
        if (void* k = class_from_name(img, ns, name)) return k;
    }
    return nullptr;
}

// field offset walking up the parent chain (fields live in obfuscated bases like XU / GenericVitals)
static long FieldOff(void* k, const char* name, void** outField = nullptr) {
    for (; k; k = class_get_parent(k))
        if (void* f = class_get_field(k, name)) { if (outField) *outField = f; return (long)field_offset(f); }
    return -1;
}

static std::string Str(void* s) {
    if (!s) return {};
    int n = string_len(s); const uint16_t* c = string_chars(s);
    std::string o; for (int i = 0; i < n && i < 64; i++) o += c[i] < 128 ? (char)c[i] : '?';
    return o;
}

template <class R> static R CallI(void* mi, void* self) { return ((R(*)(void*, void*))(*(void**)mi))(self, mi); }
template <class R> static R CallS(void* mi) { return ((R(*)(void*))(*(void**)mi))(mi); }

static bool Init() {
    if (g_ok) return true;
    void* h = dlopen("libil2cpp.so", RTLD_NOW | RTLD_NOLOAD);
    if (!h) return false;
    ld(domain_get, h, "il2cpp_domain_get"); ld(thread_attach, h, "il2cpp_thread_attach");
    ld(domain_get_assemblies, h, "il2cpp_domain_get_assemblies"); ld(assembly_get_image, h, "il2cpp_assembly_get_image");
    ld(class_from_name, h, "il2cpp_class_from_name"); ld(class_get_parent, h, "il2cpp_class_get_parent");
    ld(class_get_field, h, "il2cpp_class_get_field_from_name"); ld(class_get_method, h, "il2cpp_class_get_method_from_name");
    ld(class_get_methods, h, "il2cpp_class_get_methods"); ld(class_from_type, h, "il2cpp_class_from_type");
    ld(class_elem, h, "il2cpp_class_get_element_class"); ld(class_array_elem_size, h, "il2cpp_class_array_element_size");
    ld(class_inst_size, h, "il2cpp_class_instance_size"); ld(obj_get_class, h, "il2cpp_object_get_class");
    ld(field_offset, h, "il2cpp_field_get_offset"); ld(field_type, h, "il2cpp_field_get_type");
    ld(field_static_get, h, "il2cpp_field_static_get_value"); ld(method_param_count, h, "il2cpp_method_get_param_count");
    ld(method_ret_type, h, "il2cpp_method_get_return_type"); ld(type_name, h, "il2cpp_type_get_name");
    ld(string_chars, h, "il2cpp_string_chars"); ld(string_len, h, "il2cpp_string_length");
    if (!domain_get || !class_from_name || !field_static_get || !string_chars) return false;
    thread_attach(domain_get());

    void* kPM = FindClass("Oxide", "PlayerManager");
    void* kCam = FindClass("UnityEngine", "Camera");
    void* kTr = FindClass("UnityEngine", "Transform");
    void* kCmp = FindClass("UnityEngine", "Component");
    void* kScr = FindClass("UnityEngine", "Screen");
    if (!kPM || !kCam || !kTr || !kCmp || !kScr) return false;

    fEnabled = class_get_field(kPM, "EnabledInstances");              // static HashSet<PlayerManager>
    long ov = FieldOff(kPM, "vitals");
    mTeam = class_get_method(kPM, "get_teamName", 0);
    mTransform = class_get_method(kCmp, "get_transform", 0);
    mPosition = class_get_method(kTr, "get_position", 0);
    mMain = class_get_method(kCam, "get_main", 0);
    mW2S = class_get_method(kCam, "WorldToScreenPoint", 1);            // (Vector3)
    mScrW = class_get_method(kScr, "get_width", 0);
    mScrH = class_get_method(kScr, "get_height", 0);
    if (!fEnabled || ov < 0 || !mTransform || !mPosition || !mMain || !mW2S || !mScrW || !mScrH) return false;
    oVitals = (size_t)ov;

    // HashSet<PlayerManager> layout from the live type
    void* set = nullptr; field_static_get(fEnabled, &set);
    if (!set) return false;                                             // retry next frame, set is created lazily
    void* kSet = obj_get_class(set);
    void* fs = nullptr; long os = FieldOff(kSet, "_slots", &fs);
    long ol = FieldOff(kSet, "_lastIndex");
    if (os < 0 || ol < 0) return false;
    oSlots = (size_t)os; oLast = (size_t)ol;
    void* kArr = class_from_type(field_type(fs));
    void* kSlot = class_elem(kArr);
    long ovl = FieldOff(kSlot, "value");
    if (ovl < 0) return false;
    oSlotVal = (size_t)ovl - 0x10;                                      // value-type field offset includes boxed header
    szSlot = (size_t)class_array_elem_size(kArr);
    if (szSlot < 16 || szSlot > 64) szSlot = (size_t)class_inst_size(kSlot) - 0x10;

    // PlayerVitals -> (XU.Entity) -> XE{Health, DisplayName}
    void* kV = FindClass("Oxide", "PlayerVitals");
    void* kXE = nullptr;
    long oe = kV ? FieldOff(kV, "Entity", &kXE) : -1;
    if (oe < 0) return false;
    oEntity = (size_t)oe;
    void* fent = nullptr; FieldOff(kV, "Entity", &fent);
    kXE = class_from_type(field_type(fent));
    long oh = FieldOff(kXE, "Health"), on = FieldOff(kXE, "DisplayName");
    if (oh < 0) return false;
    oHealth = (size_t)oh; oName = on < 0 ? 0 : (size_t)on;
    void* fh = nullptr; FieldOff(kXE, "Health", &fh);
    kHpClass = class_from_type(field_type(fh));                         // Xq<float>

    // Xq<float> getter: obfuscated name, so pick by signature: 0 params -> System.Single
    void* it = nullptr;
    while (void* m = class_get_methods(kHpClass, &it)) {
        if (method_param_count(m) == 0 && strcmp(type_name(method_ret_type(m)), "System.Single") == 0) { mHpGet = m; break; }
    }
    if (!mHpGet) return false;
    g_ok = true;
    return true;
}

struct Ent { V3 pos; std::string name, team; float hp; };

static V3 PosOf(void* comp) {
    void* t = CallI<void*>(mTransform, comp);
    return t ? CallI<V3>(mPosition, t) : V3{0, 0, 0};
}

// Unity screen space: origin bottom-left, z<0 => behind camera
static bool W2S(void* cam, V3 w, ImVec2& o, float sx, float sy) {
    typedef V3 (*Fn)(void*, V3, void*);
    V3 s = ((Fn)(*(void**)mW2S))(cam, w, mW2S);
    if (s.z < 0.01f) return false;
    o = ImVec2(s.x * sx, ImGui::GetIO().DisplaySize.y - s.y * sy);
    return true;
}

static std::vector<Ent> Snapshot(V3& camPos, void*& cam) {
    std::vector<Ent> out;
    cam = CallS<void*>(mMain);
    if (!cam) return out;
    camPos = PosOf(cam);
    void* set = nullptr; field_static_get(fEnabled, &set);
    if (!set) return out;
    char* slots = *(char**)((char*)set + oSlots);
    int last = *(int*)((char*)set + oLast);
    if (!slots || last <= 0 || last > 4096) return out;
    std::string myTeam; bool haveMy = false;
    std::vector<std::pair<void*, V3>> raw;
    for (int i = 0; i < last; i++) {
        char* e = slots + 0x20 + (size_t)i * szSlot;                    // il2cpp array data starts at 0x20
        if (*(int*)e < 0) continue;                                     // free slot
        void* pm = *(void**)(e + oSlotVal);
        if (!pm) continue;
        raw.push_back({pm, PosOf(pm)});
    }
    for (auto& r : raw) {
        V3 p = r.second;
        float dx = p.x - camPos.x, dy = p.y - camPos.y, dz = p.z - camPos.z;
        float d = sqrtf(dx * dx + dy * dy + dz * dz);
        if (d < 2.5f) {                                                 // local player = the pawn sitting on the camera
            if (mTeam) { myTeam = Str(CallI<void*>(mTeam, r.first)); haveMy = true; }
            continue;
        }
        if (d > cfg.maxDist) continue;
        void* vit = *(void**)((char*)r.first + oVitals);
        if (!vit) continue;
        void* ent = *(void**)((char*)vit + oEntity);
        if (!ent) continue;
        void* hpObj = *(void**)((char*)ent + oHealth);
        Ent o{p, {}, {}, hpObj ? CallI<float>(mHpGet, hpObj) : 0.f};
        if (oName) o.name = Str(*(void**)((char*)ent + oName));
        if (mTeam) o.team = Str(CallI<void*>(mTeam, r.first));
        if (o.hp <= 0.f) continue;
        out.push_back(o);
    }
    for (auto& o : out) if (!haveMy || o.team.empty() || o.team != myTeam) o.team.clear(); // non-empty team == teammate
    return out;
}

static void Esp() {
    if (!cfg.esp) return;
    if (!g_ok && !Init()) return;                                       // Init() attaches the calling thread
    V3 cp{}; void* cam = nullptr;
    auto ents = Snapshot(cp, cam);
    if (!cam) return;
    float sw = (float)CallS<int>(mScrW), sh = (float)CallS<int>(mScrH);
    if (sw < 1 || sh < 1) return;
    ImVec2 disp = ImGui::GetIO().DisplaySize;
    float sx = disp.x / sw, sy = disp.y / sh;
    ImDrawList* dl = ImGui::GetBackgroundDrawList();
    for (auto& e : ents) {
        bool mate = !e.team.empty();
        if (mate && !cfg.team) continue;
        ImU32 col = ImGui::ColorConvertFloat4ToU32(mate ? cfg.colTeam : cfg.colEnemy);
        ImVec2 f, h;
        if (!W2S(cam, e.pos, f, sx, sy)) continue;
        if (!W2S(cam, V3{e.pos.x, e.pos.y + 1.8f, e.pos.z}, h, sx, sy)) continue;
        float bh = fabsf(f.y - h.y), bw = bh * 0.5f, top = fminf(f.y, h.y), cx = (f.x + h.x) * 0.5f;
        if (cfg.box) dl->AddRect(ImVec2(cx - bw / 2, top), ImVec2(cx + bw / 2, top + bh), col, 0, 0, 1.5f);
        if (cfg.health) {
            float k = fminf(fmaxf(e.hp / 100.f, 0.f), 1.f);             // FILL: use m_MaxHealth (GenericVitals) if max != 100
            float x = cx - bw / 2 - 4;
            dl->AddRectFilled(ImVec2(x - 1, top - 1), ImVec2(x + 2, top + bh + 1), IM_COL32(0, 0, 0, 160));
            dl->AddRectFilled(ImVec2(x, top + bh * (1.f - k)), ImVec2(x + 1, top + bh), IM_COL32(60, 255, 90, 255));
        }
        float ty = top - 14;
        if (cfg.name && !e.name.empty()) { dl->AddText(ImVec2(cx - bw / 2, ty), IM_COL32(255, 255, 255, 255), e.name.c_str()); ty -= 12; }
        if (cfg.dist) {
            char b[16]; float dx = e.pos.x - cp.x, dy = e.pos.y - cp.y, dz = e.pos.z - cp.z;
            snprintf(b, sizeof b, "%dm", (int)sqrtf(dx * dx + dy * dy + dz * dz));
            dl->AddText(ImVec2(cx - bw / 2, top + bh + 2), IM_COL32(220, 220, 220, 255), b);
        }
        if (cfg.line) dl->AddLine(ImVec2(disp.x * 0.5f, disp.y), ImVec2(cx, top + bh), col, 1.f);
    }
}

static void Menu() {
    ImGui::Checkbox("ESP", &cfg.esp);
    ImGui::Checkbox("Box", &cfg.box);
    ImGui::Checkbox("Health", &cfg.health);
    ImGui::Checkbox("Name", &cfg.name);
    ImGui::Checkbox("Distance", &cfg.dist);
    ImGui::Checkbox("Snaplines", &cfg.line);
    ImGui::Checkbox("Show team", &cfg.team);
    ImGui::SliderFloat("Max dist", &cfg.maxDist, 50.f, 1000.f, "%.0f m");
    ImGui::ColorEdit4("Enemy", &cfg.colEnemy.x, ImGuiColorEditFlags_NoInputs);
    ImGui::ColorEdit4("Team", &cfg.colTeam.x, ImGuiColorEditFlags_NoInputs);
}

} // namespace ox
